import FocusTimer from "../components/FocusTimer.jsx";

export default function FocusPage() {
  return (
    <div className="page page-narrow">
      <section className="card focus-page" aria-labelledby="fh">
        <h1 id="fh">Focus Room</h1>
        <p className="muted">A Pomodoro timer. It keeps running if you switch pages, and finished focus sessions are counted on this device.</p>
        <FocusTimer large id="page" />
      </section>
      <section className="card" aria-labelledby="amb">
        <h2 id="amb">Ambient audio</h2>
        <p className="status-pill status-soon">Not built yet</p>
        <p className="muted">Optional ambient sound controls aren't included yet, so there are no sound buttons here.</p>
      </section>
    </div>
  );
}
