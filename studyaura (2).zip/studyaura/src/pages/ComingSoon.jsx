import { Link } from "react-router-dom";
import { Icon } from "../components/Icons.jsx";

/** Honest placeholder: says exactly what is and isn't built, and what it will need. Contains no fake controls. */
export default function ComingSoon({ title, icon, status = "soon", summary, will = [], needs, phase }) {
  const pill = status === "off" ? ["status-off", "Not connected yet"] : ["status-soon", "Not built yet"];
  return (
    <div className="page">
      <section className="card placeholder" aria-labelledby="ph">
        <span className="placeholder-icon"><Icon name={icon} size={28} /></span>
        <div className="placeholder-body">
          <p className={`status-pill ${pill[0]}`}>{pill[1]}{phase ? ` · ${phase}` : ""}</p>
          <h1 id="ph">{title}</h1>
          <p>{summary}</p>
          {will.length > 0 && (
            <>
              <h2 className="small-h">Planned</h2>
              <ul className="plain-list">{will.map((w) => <li key={w}>{w}</li>)}</ul>
            </>
          )}
          {needs && (
            <p className="note"><strong>Setup path:</strong> {needs}</p>
          )}
          <Link to="/" className="btn btn-soft">Back to dashboard</Link>
        </div>
      </section>
    </div>
  );
}

export const PLACEHOLDERS = {
  "/library": {
    title: "Learning library", icon: "book", phase: "Later phase",
    summary: "Board and class selection, subjects, courses, chapters, lessons, notes, practice, revision and mock tests. The structure will be flexible because curricula vary by board and region.",
    will: ["Choose board, class/grade and country", "Subjects → chapters → lessons hierarchy that you can edit", "Link notes, practice and tests to each chapter"],
  },
  "/assistant": {
    title: "AI Study Assistant", icon: "sparkle", status: "off", phase: "Later phase",
    summary: "Explain concepts, quiz you, and help plan revision. There is no fake chatbot here: it will only appear once a real model is connected on a server.",
    will: ["Explain a concept at your level", "Quiz you on a chapter", "Suggest a revision plan from your planner"],
    needs: "add a server endpoint that holds a model API key in an environment variable (never in browser code), then the assistant turns on automatically.",
  },
  "/flashcards": {
    title: "Flashcards", icon: "cards", phase: "Phase 5",
    summary: "Create cards by hand, flip to review, and later generate cards from your imported notes.",
    will: ["Manual deck and card creation", "Flip-and-review mode", "Generate cards from saved notes"],
  },
  "/practice": {
    title: "Practice & tests", icon: "target", phase: "Phase 5",
    summary: "Quick quizzes with answer feedback, a final score and a review of the questions you missed.",
    will: ["Quick Quiz with instant feedback", "Score and mistake review", "Mock tests per chapter"],
  },
  "/planner": {
    title: "Study Planner", icon: "calendar", phase: "Later phase",
    summary: "A full planner view. Today's plan already works on the dashboard; this page will add dates beyond today.",
    will: ["Plan by date, subject, priority and estimated time", "Edit tasks and reschedule", "Week view"],
  },
  "/mood": {
    title: "Mood tracker", icon: "smile", phase: "Later phase",
    summary: "Your daily check-in already saves on the dashboard. This page will show your history over time.",
    will: ["Calendar of past check-ins", "Simple trends"],
  },
};
