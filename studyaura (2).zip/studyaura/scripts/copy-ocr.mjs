// Copies the on-device OCR engine into public/ocr so the app never loads it from a CDN.
// Runs automatically after `npm install` (postinstall) and before `npm run build`.
import { cpSync, mkdirSync, readdirSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const out = join(root, "public", "ocr");
const nm = join(root, "node_modules");
mkdirSync(out, { recursive: true });

const worker = join(nm, "tesseract.js", "dist", "worker.min.js");
const coreDir = join(nm, "tesseract.js-core");
const lang = join(nm, "@tesseract.js-data", "eng", "4.0.0_best_int", "eng.traineddata.gz");

if (![worker, coreDir, lang].every(existsSync)) {
  console.warn("[copy-ocr] OCR packages not installed yet; skipping.");
  process.exit(0);
}
cpSync(worker, join(out, "worker.min.js"));
for (const f of readdirSync(coreDir)) {
  if (/^tesseract-core(-simd)?-lstm\.wasm\.js$/.test(f)) cpSync(join(coreDir, f), join(out, f));
}
cpSync(lang, join(out, "eng.traineddata.gz"));
console.log("[copy-ocr] OCR engine copied to public/ocr");
