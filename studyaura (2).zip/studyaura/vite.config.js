import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { viteSingleFile } from "vite-plugin-singlefile";

// base "./" + single-file output: dist/index.html opens by double-click (file://) and also works
// from any static host or sub-folder. The OCR engine stays in dist/ocr and needs http(s) to run.
export default defineConfig({
  base: "./",
  plugins: [react(), viteSingleFile()],
  server: { host: true, port: 5173 },
  preview: { host: true, port: 4173 },
});
