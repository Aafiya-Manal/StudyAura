import { useId } from "react";

/*
 * StudyAura brand system
 * ----------------------
 * LogoMark   – compact flowing "S" + spark. Used in the sidebar and favicon. Holds up at 24 px.
 * AppIcon    – square app icon (dark or light tile).
 * Wordmark   – mark + "StudyAura" lettering, optional tagline.
 * variant="mono" uses currentColor only (one-colour print, watermarks, light/dark UI chrome).
 */

const S_PATH = "M66 27C54 12 26 18 31 40C35 56 72 52 72 71C72 90 40 92 27 76";
const STAR_PATH = "M86 4C87.5 12 91 15.5 99 17C91 18.5 87.5 22 86 30C84.5 22 81 18.5 73 17C81 15.5 84.5 12 86 4Z";

export const BRAND = {
  violet: "#6C4BFF",
  violetLight: "#9B7BFF",
  blue: "#2FB8FF",
  spark: "#5CCBFF",
  navy: "#0B0B24",
};

function Gradient({ id }) {
  return (
    <linearGradient id={id} x1="0.1" y1="0" x2="0.9" y2="1">
      <stop offset="0" stopColor={BRAND.violetLight} />
      <stop offset="0.5" stopColor={BRAND.violet} />
      <stop offset="1" stopColor={BRAND.blue} />
    </linearGradient>
  );
}

function MarkShapes({ gradId, mono }) {
  return (
    <>
      <path
        d={S_PATH}
        fill="none"
        stroke={mono ? "currentColor" : `url(#${gradId})`}
        strokeWidth="16"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d={STAR_PATH} fill={mono ? "currentColor" : BRAND.spark} />
    </>
  );
}

export function LogoMark({ size = 32, variant = "color", title = "StudyAura", decorative = false, className = "" }) {
  const gradId = useId().replace(/:/g, "");
  const mono = variant === "mono";
  return (
    <svg
      className={className}
      width={size}
      height={size}
      viewBox="0 0 100 100"
      role={decorative ? undefined : "img"}
      aria-hidden={decorative ? "true" : undefined}
      aria-label={decorative ? undefined : title}
      focusable="false"
    >
      {!mono && (
        <defs>
          <Gradient id={gradId} />
        </defs>
      )}
      <MarkShapes gradId={gradId} mono={mono} />
    </svg>
  );
}

export function AppIcon({ size = 64, tone = "dark", title = "StudyAura app icon" }) {
  const uid = useId().replace(/:/g, "");
  const gradId = `g${uid}`;
  const bgId = `b${uid}`;
  const dark = tone === "dark";
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" role="img" aria-label={title} focusable="false">
      <defs>
        <Gradient id={gradId} />
        <radialGradient id={bgId} cx="0.3" cy="0.2" r="1">
          {dark ? (
            <>
              <stop offset="0" stopColor="#2A2260" />
              <stop offset="1" stopColor={BRAND.navy} />
            </>
          ) : (
            <>
              <stop offset="0" stopColor="#FFFFFF" />
              <stop offset="1" stopColor="#E9E3FF" />
            </>
          )}
        </radialGradient>
      </defs>
      <rect width="100" height="100" rx="24" fill={`url(#${bgId})`} />
      <rect x="0.75" y="0.75" width="98.5" height="98.5" rx="23.5" fill="none" stroke={dark ? "#ffffff22" : "#6C4BFF22"} strokeWidth="1.5" />
      <g transform="translate(17 17) scale(0.66)">
        <MarkShapes gradId={gradId} mono={false} />
      </g>
    </svg>
  );
}

/** Mark + lettering. `size` is the mark size in px; text scales with it. */
export function Wordmark({ size = 32, variant = "color", tagline = false, className = "" }) {
  const mono = variant === "mono";
  return (
    <span className={`wordmark ${className}`} style={{ "--wm": `${size}px` }}>
      <LogoMark size={size} variant={variant} decorative />
      <span className="wordmark-text">
        <span className="wordmark-name" aria-label="StudyAura">
          <span aria-hidden="true">Study</span>
          <span aria-hidden="true" className={mono ? "" : "wordmark-aura"}>
            Aura
          </span>
        </span>
        {tagline && (
          <span className="wordmark-tag" aria-hidden="true">
            LEARN • GROW • SHINE
          </span>
        )}
      </span>
    </span>
  );
}
