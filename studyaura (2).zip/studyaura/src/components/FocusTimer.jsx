import { useFocus, MODES } from "../context/FocusContext.jsx";
import { Icon } from "./Icons.jsx";

const R = 52;
const C = 2 * Math.PI * R;

/** Real Pomodoro timer. State lives in FocusContext so it keeps running while you move between pages. */
export default function FocusTimer({ large = false, id }) {
  const f = useFocus();
  const running = f.status === "running";
  const done = f.status === "done";
  const primary = running ? f.pause : f.start;

  return (
    <div className={`timer ${large ? "timer-large" : ""}`} id={id}>
      <div className="mode-switch" role="group" aria-label="Timer mode">
        {Object.entries(MODES).map(([key, m]) => (
          <button
            key={key}
            type="button"
            className={`chip ${f.mode === key ? "chip-on" : ""}`}
            aria-pressed={f.mode === key}
            onClick={() => f.setMode(key)}
            disabled={running}
          >
            {m.label} · {m.minutes}m
          </button>
        ))}
      </div>

      <div className="ring" role="timer" aria-label={`${MODES[f.mode].label} timer`}>
        <svg viewBox="0 0 120 120" aria-hidden="true" focusable="false">
          <defs>
            <linearGradient id={`rg-${id || "d"}`} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#8B6BFF" />
              <stop offset="1" stopColor="#2FB8FF" />
            </linearGradient>
          </defs>
          <circle cx="60" cy="60" r={R} className="ring-track" />
          <circle
            cx="60"
            cy="60"
            r={R}
            className="ring-bar"
            stroke={`url(#rg-${id || "d"})`}
            strokeDasharray={C}
            strokeDashoffset={C * (1 - f.progress)}
            transform="rotate(-90 60 60)"
          />
        </svg>
        <div className="ring-text">
          <span className="ring-time" aria-live="off">{f.label}</span>
          <span className="ring-sub">{done ? "Session complete" : MODES[f.mode].label}</span>
        </div>
      </div>

      <div className="timer-actions">
        <button type="button" className="btn btn-primary" onClick={primary} disabled={done}>
          <Icon name={running ? "pause" : "play"} size={16} />
          {running ? "Pause" : f.status === "paused" ? "Resume" : "Start"}
        </button>
        <button type="button" className="btn btn-ghost" onClick={f.reset} disabled={f.status === "idle"}>
          <Icon name="reset" size={16} /> Reset
        </button>
      </div>

      <p className="timer-meta">
        Today: <strong>{f.sessionsToday}</strong> session{f.sessionsToday === 1 ? "" : "s"} · <strong>{f.minutesToday}</strong> min focused
      </p>
      <p className="sr-only" role="status">
        {done ? `${MODES[f.mode].label} complete.` : ""}
      </p>
    </div>
  );
}
