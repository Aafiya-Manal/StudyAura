# StudyAura 2.0 — Phases 1–3 (+ on-device text reading)

Responsive study platform shell: new brand system + working dashboard. Built with Vite + React 18 + React Router. No backend yet.

## Run it

**Easiest: open the built app.** `npm run build` makes `dist/index.html`, one self-contained file. Extract the zip first (opening a file from inside a zip shows a blank page), then double-click `index.html`. Everything works that way **except reading text from photos**, because browsers block the reading engine for local files; the app says so on that screen.

**For photo reading, serve the folder over http** (any one of these, from inside `dist/`):
```bash
python3 -m http.server 8000        # then open http://localhost:8000
npx serve                          # or this
```
Or upload the `dist` folder to any static host (Netlify Drop, GitHub Pages, Vercel). It uses hash URLs (`/#/notes`), so no server routing setup is needed.

**Development**
```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # outputs dist/
```

## Status

**Works now (real state, saved in this browser only)**
- Logo system: wordmark, compact mark, square app icon (dark/light), monochrome. See `/brand`.
- Responsive shell: sidebar (desktop), drawer + bottom tab bar (mobile), skip link, focus rings, reduced-motion support.
- Dashboard: time-based greeting, subjects (add / mark chapters / delete with confirm; progress is computed from your own numbers), today's plan (add / complete / delete), mood check-in, daily motivation line.
- Focus timer (Pomodoro 25/5): start, pause, reset; keeps running across pages; completed focus sessions counted per day.
- AuraPet: optional floating helper with shortcuts; hides itself during a running focus session; toggle in Settings.
- Settings: AuraPet toggle, clear all local data (with confirm), privacy note.

**Notes Studio + "Make notes from images" (Phase 3, works now, local only)**
- Upload up to 12 JPG/PNG/WEBP photos (10 MB each) by picking, dragging, or camera capture. Unsupported, oversized and corrupt files get specific messages; dark and low-resolution photos are warned about (blur is NOT detected).
- Thumbnails with reorder, real 90° rotate (pixels rotated), remove.
- **On-device text reading (Tesseract, English, no server, no upload).** Photos are cleaned first (size, shadow removal, contrast), read page by page with progress and Cancel, and a sideways page is turned automatically when the first read is poor. Each page gets an honest quality label. Words the engine is unsure about, **and any formula/equation-like text (H2O, C6H12O6, x2, numbers on formula lines)**, are marked "[check this: …]" because OCR often reads O as 0 with high confidence. Engine files live in `public/ocr` (copied from node_modules by `scripts/copy-ocr.mjs` on install/build, about 11 MB; gitignored).
  - Measured on generated fixtures: clean page 96% word recall, shadowed/noisy phone photo 96%, sideways page 96%; 0 confident-but-wrong words. Blank page reported as "No text found". Handwriting stand-in rated "Poor read" with a prompt to type it. **Not tested on real handwriting or real phone photos.**
  - Limits: English only for now, printed text only (handwriting is unreliable), maths layout (fractions, exponents) is not understood, diagrams are not read.
- Review screen: original page beside an editable text box; "check this" flag button; flagged items are counted on the note and in the list.
- Styles that work today: Clean transcription, Exam revision layout (empty sections to fill, your text kept under "Source text"). Optional hand-drawn flowchart starter.
- Notes: create, edit, save, search, duplicate, delete (confirm), copy as Markdown, download .md / .txt.
- Flowcharts: write Mermaid text, live SVG preview, clear error on invalid text.
- Images are not saved with the note (text only). Nothing is uploaded.

**Needs setup / not connected**
- Handwriting recognition — needs a server-side vision model (not built). On-device reading handles printed text only.
- Important points, Q&A sheet, flashcards and automatic flowcharts from text — need an AI model on a server (API key in an environment variable).
- AI Study Assistant — needs a server endpoint holding a model API key in an environment variable.

**Not built yet (clearly labelled in the UI)**
- PDF export, saving original images with notes, flashcards/quiz from notes, learning library, full planner, flashcards, quizzes/tests, mood history, ambient audio, accounts and cross-device sync.

## Data & privacy
All data lives in `localStorage` under the `studyaura:v2:` prefix: local to this browser/device, not synced, lost if site data is cleared. Nothing is uploaded.

## Test checklist (run on each milestone)
1. Empty states show on first load (no fake subjects/progress).
2. Add subjects and tasks; tick chapters/tasks; reload — everything persists.
3. Delete asks for confirmation; Cancel keeps the item.
4. Start timer → countdown, tab title updates, pet hides; pause holds; navigate to Focus — state kept.
5. Settings: pet toggle works; "Clear all data" empties the app.
6. Keyboard only: Tab from page load (skip link first), all controls reachable with a visible ring; Esc closes mobile drawer / pet bubble / dialogs.
7. Resize to 390px and 820px: no horizontal scroll; tap targets ≥ 32px.
8. Notes: upload mixed valid/invalid files, reorder, rotate, remove; review; create note; edit, save, export .md/.txt, search, duplicate, delete.
9. `/brand`: mark legible at 24 px on light and dark.

## Structure
```
src/brand/Logo.jsx          LogoMark, AppIcon, Wordmark
src/context/                DataContext (subjects, tasks, mood, settings), FocusContext (timer)
src/components/             Layout, FocusTimer, AuraPet, ConfirmDialog, Icons
src/pages/                  Dashboard, FocusPage, SettingsPage, BrandPage, ComingSoon (honest placeholders)
src/lib/storage.js          localStorage hook with failure detection
src/lib/ocr.js              on-device reading: preprocess, recognise, rotate fallback, flagging
scripts/copy-ocr.mjs        copies the OCR engine into public/ocr (postinstall/prebuild)
```
