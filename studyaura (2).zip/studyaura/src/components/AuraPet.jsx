import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useFocus } from "../context/FocusContext.jsx";
import { useData } from "../context/DataContext.jsx";

/** Original AuraPet character – a soft star-sprite. Pure SVG + CSS, no third-party artwork. */
export function PetArt({ size = 64, waving = false }) {
  return (
    <svg className={`pet-art ${waving ? "pet-wave" : ""}`} width={size} height={size} viewBox="0 0 80 80" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id="pet-body" x1="0.2" y1="0" x2="0.8" y2="1">
          <stop offset="0" stopColor="#9B86FF" />
          <stop offset="1" stopColor="#4C7DFF" />
        </linearGradient>
      </defs>
      <path d="M40 8c13 0 22 10 22 24 0 6 3 8 3 15 0 10-9 17-25 17S15 57 15 47c0-7 3-9 3-15C18 18 27 8 40 8z" fill="url(#pet-body)" />
      <ellipse cx="32" cy="35" rx="3.2" ry="4.2" fill="#fff" />
      <ellipse cx="48" cy="35" rx="3.2" ry="4.2" fill="#fff" />
      <circle cx="33" cy="36" r="1.6" fill="#1a1550" />
      <circle cx="49" cy="36" r="1.6" fill="#1a1550" />
      <path d="M34 45c2.5 3 9.5 3 12 0" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" fill="none" />
      <circle cx="26" cy="43" r="3" fill="#ff9ad5" opacity="0.55" />
      <circle cx="54" cy="43" r="3" fill="#ff9ad5" opacity="0.55" />
      <g className="pet-arm">
        <path d="M64 42c6-2 8-8 6-12" stroke="#7F6BFF" strokeWidth="5" strokeLinecap="round" fill="none" />
      </g>
      <path d="M62 8c.7 3.5 2.5 5.3 6 6-3.5.7-5.3 2.5-6 6-.7-3.5-2.5-5.3-6-6 3.5-.7 5.3-2.5 6-6z" fill="#7BD3FF" />
    </svg>
  );
}

/** Small optional floating helper. Hidden while a focus session is running, never covers the page by default. */
export default function AuraPet() {
  const { settings, setPet } = useData();
  const focus = useFocus();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const [waving, setWaving] = useState(false);
  const wrap = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    const onDoc = (e) => wrap.current && !wrap.current.contains(e.target) && setOpen(false);
    document.addEventListener("keydown", onKey);
    document.addEventListener("pointerdown", onDoc);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("pointerdown", onDoc);
    };
  }, [open]);

  useEffect(() => {
    if (focus.live) setOpen(false);
  }, [focus.live]);

  if (!settings.pet || focus.live) return null;

  const go = (to) => {
    setOpen(false);
    nav(to);
  };

  return (
    <div className="pet" ref={wrap}>
      {open && (
        <div className="pet-bubble" role="dialog" aria-label="AuraPet shortcuts">
          <p className="pet-title">Hi! Quick shortcuts</p>
          <button type="button" onClick={() => go("/focus")}>Start a focus session</button>
          <button type="button" onClick={() => go("/")}>Today's plan</button>
          <button type="button" onClick={() => go("/notes")}>Notes Studio</button>
          <button type="button" className="pet-hide" onClick={() => setPet(false)}>Hide AuraPet</button>
        </div>
      )}
      <button
        type="button"
        className="pet-btn"
        aria-label="AuraPet helper"
        aria-expanded={open}
        onClick={() => {
          setOpen((o) => !o);
          setWaving(true);
          window.setTimeout(() => setWaving(false), 1200);
        }}
      >
        <PetArt size={56} waving={waving} />
      </button>
    </div>
  );
}
