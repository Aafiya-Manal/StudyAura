import React from "react";
import { createRoot } from "react-dom/client";
import { HashRouter, Route, Routes, useLocation } from "react-router-dom";
import "@fontsource/space-grotesk/400.css";
import "@fontsource/space-grotesk/500.css";
import "@fontsource/space-grotesk/700.css";
import "./styles.css";

import Layout from "./components/Layout.jsx";
import { DataProvider } from "./context/DataContext.jsx";
import { FocusProvider } from "./context/FocusContext.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import FocusPage from "./pages/FocusPage.jsx";
import SettingsPage from "./pages/SettingsPage.jsx";
import BrandPage from "./pages/BrandPage.jsx";
import NotesPage from "./pages/NotesPage.jsx";
import NoteEditor from "./pages/NoteEditor.jsx";
import ImageNotesWizard from "./pages/ImageNotesWizard.jsx";
import { NotesProvider } from "./context/NotesContext.jsx";
import ComingSoon, { PLACEHOLDERS } from "./pages/ComingSoon.jsx";

/** Move focus to the main region on navigation so keyboard and screen-reader users land on the new page. */
function RouteFocus() {
  const { pathname } = useLocation();
  const first = React.useRef(true);
  React.useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    document.getElementById("main")?.focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function NotFound() {
  return <ComingSoon title="Page not found" icon="close" summary="That page doesn't exist." />;
}

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <HashRouter>
      <DataProvider>
        <NotesProvider>
        <FocusProvider>
          <RouteFocus />
          <Routes>
            <Route element={<Layout />}>
              <Route index element={<Dashboard />} />
              <Route path="focus" element={<FocusPage />} />
              <Route path="settings" element={<SettingsPage />} />
              <Route path="notes" element={<NotesPage />} />
              <Route path="notes/from-images" element={<ImageNotesWizard />} />
              <Route path="notes/:id" element={<NoteEditor />} />
              <Route path="brand" element={<BrandPage />} />
              {Object.entries(PLACEHOLDERS).map(([path, props]) => (
                <Route key={path} path={path.slice(1)} element={<ComingSoon {...props} />} />
              ))}
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </FocusProvider>
        </NotesProvider>
      </DataProvider>
    </HashRouter>
  </React.StrictMode>,
);
