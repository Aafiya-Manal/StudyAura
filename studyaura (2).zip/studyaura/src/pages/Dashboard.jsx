import { useMemo, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Icon } from "../components/Icons.jsx";
import FocusTimer from "../components/FocusTimer.jsx";
import ConfirmDialog from "../components/ConfirmDialog.jsx";
import { PetArt } from "../components/AuraPet.jsx";
import { PRIORITIES, useData } from "../context/DataContext.jsx";
import { useFocus } from "../context/FocusContext.jsx";
import { todayKey } from "../lib/storage.js";

const QUOTES = [
  "Progress, not perfection.",
  "Discipline today builds the freedom you want tomorrow.",
  "One focused session beats three distracted hours.",
  "You don't have to be great to start, but you have to start to be great.",
  "Small steps, repeated daily, add up.",
  "Understanding beats memorising. Ask why.",
  "Rest is part of studying. Take the break.",
];

const MOODS = [
  { v: 1, label: "Very low" },
  { v: 2, label: "Low" },
  { v: 3, label: "Okay" },
  { v: 4, label: "Good" },
  { v: 5, label: "Great" },
];

function Face({ v }) {
  const mouth = { 1: "M9 17c1.5-2.5 6.5-2.5 8 0", 2: "M9.5 16.5c1.2-1.4 5.8-1.4 7 0", 3: "M9.5 16h7", 4: "M9.5 15.5c1.2 1.6 5.8 1.6 7 0", 5: "M8.5 14.8c1.5 3 7.5 3 9 0z" }[v];
  return (
    <svg width="28" height="28" viewBox="0 0 26 26" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
      <circle cx="13" cy="13" r="10.5" />
      <path d="M9.5 10.5h.01M16.5 10.5h.01" strokeWidth="2.2" />
      <path d={mouth} fill={v === 5 ? "currentColor" : "none"} />
    </svg>
  );
}

function greeting() {
  const h = new Date().getHours();
  if (h < 5) return "Burning the midnight oil";
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

const dayOfYear = () => Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0)) / 86400000);

export default function Dashboard() {
  const nav = useNavigate();
  const data = useData();
  const focus = useFocus();
  const { subjects, tasks } = data;

  const [subName, setSubName] = useState("");
  const [subTotal, setSubTotal] = useState(10);
  const [showSubForm, setShowSubForm] = useState(false);
  const [taskTitle, setTaskTitle] = useState("");
  const [taskPriority, setTaskPriority] = useState("medium");
  const [taskMinutes, setTaskMinutes] = useState("");
  const [taskSubject, setTaskSubject] = useState("");
  const [confirm, setConfirm] = useState(null); // { kind, id, name }
  const timerRef = useRef(null);

  const today = todayKey();
  const todays = useMemo(() => tasks.filter((t) => t.date === today), [tasks, today]);
  const doneToday = todays.filter((t) => t.done).length;
  const chaptersTotal = subjects.reduce((a, s) => a + s.total, 0);
  const chaptersDone = subjects.reduce((a, s) => a + s.done, 0);
  const overall = chaptersTotal ? Math.round((chaptersDone / chaptersTotal) * 100) : null;
  const quote = QUOTES[dayOfYear() % QUOTES.length];

  const petLine = (() => {
    if (!todays.length) return "Add one small task to get today going.";
    if (doneToday === todays.length) return "All of today's tasks are done. Nice work!";
    return `${doneToday} of ${todays.length} tasks done today. Keep going!`;
  })();

  const heroLine = (() => {
    if (!subjects.length && !todays.length) return "Add your subjects and today's tasks to start tracking real progress.";
    if (overall !== null) return `You've completed ${chaptersDone} of ${chaptersTotal} chapters across your subjects (${overall}%).`;
    return `${doneToday} of ${todays.length} tasks done today.`;
  })();

  const submitSubject = (e) => {
    e.preventDefault();
    if (!subName.trim()) return;
    data.addSubject({ name: subName, total: Number(subTotal) || 1 });
    setSubName("");
    setSubTotal(10);
    setShowSubForm(false);
  };

  const submitTask = (e) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;
    data.addTask({ title: taskTitle, priority: taskPriority, minutes: Number(taskMinutes) || 0, subject: taskSubject });
    setTaskTitle("");
    setTaskMinutes("");
  };

  const startPomodoro = () => {
    timerRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
    if (focus.status === "idle" || focus.status === "paused") focus.start();
  };

  const doConfirm = () => {
    if (confirm?.kind === "subject") data.removeSubject(confirm.id);
    if (confirm?.kind === "task") data.removeTask(confirm.id);
    setConfirm(null);
  };

  return (
    <div className="dash">
      <div className="dash-main">
        {/* Greeting */}
        <section className="hero card" aria-labelledby="hello">
          <div>
            <h1 id="hello">{greeting()}, Future Leader</h1>
            <p>{heroLine}</p>
          </div>
          {overall !== null && (
            <div className="hero-stat" aria-label={`Overall chapter progress ${overall} percent`}>
              <strong>{overall}%</strong>
              <span>chapters done</span>
            </div>
          )}
        </section>

        {/* Quick actions */}
        <section aria-labelledby="qa" className="qa-wrap">
          <h2 id="qa" className="sr-only">Quick actions</h2>
          <Link to="/notes" className="notes-cta">
            <span className="notes-cta-icon"><Icon name="image" size={26} /></span>
            <span className="notes-cta-body">
              <strong>Make notes from images</strong>
              <span>Photograph textbook pages, check the text it reads, then save notes and flowcharts.</span>
            </span>
            <span className="status-pill status-soon">Beta · reads printed text</span>
            <Icon name="arrow" className="notes-cta-arrow" />
          </Link>

          <div className="qa-grid">
            <Link to="/library" className="qa qa-violet">
              <span className="qa-icon"><Icon name="book" /></span>
              <strong>Continue learning</strong>
              <span>Courses &amp; chapters</span>
              <em className="status-pill status-soon">Soon</em>
            </Link>
            <Link to="/assistant" className="qa qa-blue">
              <span className="qa-icon"><Icon name="sparkle" /></span>
              <strong>AI Assistant</strong>
              <span>Needs a model connected</span>
              <em className="status-pill status-off">Not connected</em>
            </Link>
            <button type="button" className="qa qa-rose" onClick={startPomodoro}>
              <span className="qa-icon"><Icon name="timer" /></span>
              <strong>Start a Pomodoro</strong>
              <span>25-minute focus session</span>
              <em className="status-pill status-live">Works now</em>
            </button>
            <Link to="/flashcards" className="qa qa-amber">
              <span className="qa-icon"><Icon name="cards" /></span>
              <strong>Create flashcards</strong>
              <span>Manual &amp; from notes</span>
              <em className="status-pill status-soon">Soon</em>
            </Link>
          </div>
        </section>

        {/* Subjects */}
        <section className="card" aria-labelledby="subj">
          <div className="card-head">
            <h2 id="subj">My Subjects</h2>
            <button type="button" className="btn btn-soft btn-sm" onClick={() => setShowSubForm((s) => !s)} aria-expanded={showSubForm}>
              <Icon name="plus" size={16} /> Add subject
            </button>
          </div>

          {showSubForm && (
            <form className="inline-form" onSubmit={submitSubject}>
              <label>
                <span>Subject name</span>
                <input value={subName} onChange={(e) => setSubName(e.target.value)} placeholder="e.g. Mathematics" required maxLength={40} autoFocus />
              </label>
              <label>
                <span>Total chapters</span>
                <input type="number" min="1" max="200" value={subTotal} onChange={(e) => setSubTotal(e.target.value)} required />
              </label>
              <button type="submit" className="btn btn-primary">Save</button>
            </form>
          )}

          {subjects.length === 0 ? (
            <div className="empty">
              <p><strong>No subjects yet.</strong></p>
              <p>Add the subjects you're studying, then tick off chapters as you finish them. Curricula differ by board and country, so you set the chapter count.</p>
            </div>
          ) : (
            <ul className="subjects">
              {subjects.map((s) => {
                const pct = Math.round((s.done / s.total) * 100);
                return (
                  <li key={s.id} className={`subject tint-${s.color}`}>
                    <div className="subject-top">
                      <span className="subject-name">{s.name}</span>
                      <button type="button" className="icon-btn icon-btn-sm" aria-label={`Delete ${s.name}`} onClick={() => setConfirm({ kind: "subject", id: s.id, name: s.name })}>
                        <Icon name="trash" size={16} />
                      </button>
                    </div>
                    <div className="progress" role="progressbar" aria-label={`${s.name} progress`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct}>
                      <span style={{ width: `${pct}%` }} />
                    </div>
                    <div className="subject-bottom">
                      <span>{s.done}/{s.total} chapters · {pct}%</span>
                      <span className="stepper">
                        <button type="button" onClick={() => data.setSubjectDone(s.id, -1)} disabled={s.done === 0} aria-label={`Remove one completed chapter from ${s.name}`}><Icon name="minus" size={14} /></button>
                        <button type="button" onClick={() => data.setSubjectDone(s.id, 1)} disabled={s.done === s.total} aria-label={`Mark one more chapter done in ${s.name}`}><Icon name="plus" size={14} /></button>
                      </span>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        {/* Plan + pet */}
        <div className="plan-row">
          <section className="card plan" aria-labelledby="plan">
            <div className="card-head">
              <h2 id="plan">Today's Study Plan</h2>
              <span className="muted">{todays.length ? `${doneToday}/${todays.length} done` : ""}</span>
            </div>

            <form className="task-form" onSubmit={submitTask}>
              <label className="grow">
                <span className="sr-only">Task</span>
                <input value={taskTitle} onChange={(e) => setTaskTitle(e.target.value)} placeholder="Add a task, e.g. Revise Chapter 4" maxLength={120} />
              </label>
              <label>
                <span className="sr-only">Subject</span>
                <select value={taskSubject} onChange={(e) => setTaskSubject(e.target.value)}>
                  <option value="">No subject</option>
                  {subjects.map((s) => <option key={s.id} value={s.name}>{s.name}</option>)}
                </select>
              </label>
              <label>
                <span className="sr-only">Priority</span>
                <select value={taskPriority} onChange={(e) => setTaskPriority(e.target.value)}>
                  {PRIORITIES.map((p) => <option key={p} value={p}>{p[0].toUpperCase() + p.slice(1)}</option>)}
                </select>
              </label>
              <label>
                <span className="sr-only">Estimated minutes</span>
                <input type="number" min="0" max="600" value={taskMinutes} onChange={(e) => setTaskMinutes(e.target.value)} placeholder="min" className="w-min" />
              </label>
              <button type="submit" className="btn btn-primary" disabled={!taskTitle.trim()}>Add</button>
            </form>

            {todays.length === 0 ? (
              <div className="empty">
                <p><strong>Nothing planned for today.</strong></p>
                <p>Add your first task above. It's saved on this device.</p>
              </div>
            ) : (
              <ul className="tasks">
                {todays.map((t) => (
                  <li key={t.id} className={t.done ? "is-done" : ""}>
                    <label className="check">
                      <input type="checkbox" checked={t.done} onChange={() => data.toggleTask(t.id)} />
                      <span className="check-box" aria-hidden="true"><Icon name="check" size={14} strokeWidth={3} /></span>
                      <span className="task-title">{t.title}</span>
                    </label>
                    <span className="task-meta">
                      {t.subject && <span>{t.subject}</span>}
                      <span className={`prio prio-${t.priority}`}>{t.priority}</span>
                      {t.minutes > 0 && <span>{t.minutes} min</span>}
                    </span>
                    <button type="button" className="icon-btn icon-btn-sm" aria-label={`Delete task ${t.title}`} onClick={() => setConfirm({ kind: "task", id: t.id, name: t.title })}>
                      <Icon name="trash" size={16} />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <aside className="card pet-card" aria-label="AuraPet">
            <PetArt size={92} />
            <p>{petLine}</p>
            <Link to="/focus" className="btn btn-soft btn-sm">Open Focus Room</Link>
          </aside>
        </div>
      </div>

      <div className="dash-rail">
        <section className="card" aria-labelledby="ft" ref={timerRef}>
          <div className="card-head"><h2 id="ft">Focus Timer</h2></div>
          <FocusTimer id="dash" />
        </section>

        <section className="card" aria-labelledby="mood">
          <div className="card-head"><h2 id="mood">Mood Check-in</h2></div>
          <p className="muted" id="mood-q">How are you feeling today?</p>
          <div className="moods" role="group" aria-labelledby="mood-q">
            {MOODS.map((m) => (
              <button key={m.v} type="button" className={`mood mood-${m.v}`} aria-pressed={data.todayMood === m.v} aria-label={m.label} title={m.label} onClick={() => data.setMood(m.v)}>
                <Face v={m.v} />
              </button>
            ))}
          </div>
          <p className="muted small" role="status">
            {data.todayMood ? `Saved on this device: ${MOODS[data.todayMood - 1].label.toLowerCase()}.` : "Saved on this device only. A history view is coming."}
          </p>
        </section>

        <section className="card quote" aria-labelledby="dm">
          <div className="card-head"><h2 id="dm">Daily Motivation</h2></div>
          <blockquote>“{quote}”</blockquote>
        </section>
      </div>

      <ConfirmDialog
        open={!!confirm}
        title={confirm?.kind === "subject" ? "Delete this subject?" : "Delete this task?"}
        message={confirm ? `“${confirm.name}” will be removed from this device. This can't be undone.` : ""}
        onConfirm={doConfirm}
        onCancel={() => setConfirm(null)}
      />
    </div>
  );
}
