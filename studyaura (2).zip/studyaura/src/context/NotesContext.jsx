import { createContext, useCallback, useContext, useMemo } from "react";
import { uid, useLocalStorage } from "../lib/storage.js";

const NotesContext = createContext(null);

export function NotesProvider({ children }) {
  const [notes, setNotes] = useLocalStorage("notes", []);

  const add = useCallback(
    (n = {}) => {
      const id = uid();
      const now = new Date().toISOString();
      setNotes((p) => [{ id, createdAt: now, updatedAt: now, title: "Untitled note", subject: "", grade: "", chapter: "", body: "", flow: "", source: "manual", ...n }, ...p]);
      return id;
    },
    [setNotes],
  );

  const update = useCallback(
    (id, patch) => setNotes((p) => p.map((n) => (n.id === id ? { ...n, ...patch, updatedAt: new Date().toISOString() } : n))),
    [setNotes],
  );

  const duplicate = useCallback(
    (id) => {
      const nid = uid();
      const now = new Date().toISOString();
      setNotes((p) => {
        const src = p.find((n) => n.id === id);
        if (!src) return p;
        return [{ ...src, id: nid, title: `${src.title} (copy)`, createdAt: now, updatedAt: now }, ...p];
      });
      return nid;
    },
    [setNotes],
  );

  const remove = useCallback((id) => setNotes((p) => p.filter((n) => n.id !== id)), [setNotes]);

  const value = useMemo(() => ({ notes, add, update, duplicate, remove }), [notes, add, update, duplicate, remove]);
  return <NotesContext.Provider value={value}>{children}</NotesContext.Provider>;
}

export const useNotes = () => useContext(NotesContext);

export const countFlags = (text) => (text.match(/\[check this/gi) || []).length;

export function toMarkdown(n) {
  const meta = [n.subject, n.grade && `Class ${n.grade}`, n.chapter].filter(Boolean).join(" · ");
  let out = `# ${n.title}\n\n`;
  if (meta) out += `*${meta}*\n\n`;
  out += `${n.body.trim()}\n`;
  if (n.flow?.trim()) out += `\n## Flowchart\n\n\`\`\`mermaid\n${n.flow.trim()}\n\`\`\`\n`;
  return out;
}

export function toText(n) {
  const meta = [n.subject, n.grade && `Class ${n.grade}`, n.chapter].filter(Boolean).join(" · ");
  let out = `${n.title}\n${"=".repeat(Math.min(60, n.title.length))}\n`;
  if (meta) out += `${meta}\n`;
  out += `\n${n.body.trim()}\n`;
  if (n.flow?.trim()) out += `\nFlowchart (Mermaid text)\n------------------------\n${n.flow.trim()}\n`;
  return out;
}

export function download(filename, content, type = "text/plain") {
  const url = URL.createObjectURL(new Blob([content], { type: `${type};charset=utf-8` }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export const safeName = (t) => (t || "note").replace(/[^\w\- ]+/g, "").trim().replace(/\s+/g, "-").slice(0, 60) || "note";
