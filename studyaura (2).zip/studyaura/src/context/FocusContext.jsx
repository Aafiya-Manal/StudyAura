import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { todayKey, useLocalStorage } from "../lib/storage.js";

const FocusContext = createContext(null);

export const MODES = {
  focus: { label: "Focus", minutes: 25 },
  break: { label: "Short break", minutes: 5 },
};

const fmt = (ms) => {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const m = String(Math.floor(total / 60)).padStart(2, "0");
  const s = String(total % 60).padStart(2, "0");
  return `${m}:${s}`;
};

export function FocusProvider({ children }) {
  const [mode, setModeState] = useState("focus");
  const [status, setStatus] = useState("idle"); // idle | running | paused | done
  const [remaining, setRemaining] = useState(MODES.focus.minutes * 60 * 1000);
  const endsAt = useRef(0);
  const [sessions, setSessions] = useLocalStorage("sessions", []);

  const total = MODES[mode].minutes * 60 * 1000;

  const setMode = useCallback((m) => {
    setModeState(m);
    setStatus("idle");
    setRemaining(MODES[m].minutes * 60 * 1000);
  }, []);

  const start = useCallback(() => {
    endsAt.current = Date.now() + remaining;
    setStatus("running");
  }, [remaining]);

  const pause = useCallback(() => {
    setRemaining(Math.max(0, endsAt.current - Date.now()));
    setStatus("paused");
  }, []);

  const reset = useCallback(() => {
    setStatus("idle");
    setRemaining(total);
  }, [total]);

  // Timestamp-based ticking so background-tab throttling doesn't make the clock drift.
  useEffect(() => {
    if (status !== "running") return undefined;
    const id = window.setInterval(() => {
      const left = endsAt.current - Date.now();
      if (left <= 0) {
        setRemaining(0);
        setStatus("done");
        if (mode === "focus") {
          setSessions((prev) => [...prev, { at: new Date().toISOString(), day: todayKey(), minutes: MODES.focus.minutes }]);
        }
      } else {
        setRemaining(left);
      }
    }, 250);
    return () => window.clearInterval(id);
  }, [status, mode, setSessions]);

  // Show the countdown in the tab title while a session is live.
  useEffect(() => {
    if (status === "running" || status === "paused") {
      document.title = `${fmt(remaining)} · ${MODES[mode].label} — StudyAura`;
    } else {
      document.title = "StudyAura";
    }
  }, [status, remaining, mode]);

  const today = todayKey();
  const sessionsToday = useMemo(() => sessions.filter((s) => s.day === today), [sessions, today]);

  const value = useMemo(
    () => ({
      mode, setMode, status, remaining, total, label: fmt(remaining),
      progress: total ? 1 - remaining / total : 0,
      start, pause, reset,
      sessionsToday: sessionsToday.length,
      minutesToday: sessionsToday.reduce((a, s) => a + s.minutes, 0),
      live: status === "running",
    }),
    [mode, setMode, status, remaining, total, start, pause, reset, sessionsToday],
  );
  return <FocusContext.Provider value={value}>{children}</FocusContext.Provider>;
}

export const useFocus = () => useContext(FocusContext);
