import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FLOW_STARTER } from "../components/FlowchartView.jsx";
import ConfirmDialog from "../components/ConfirmDialog.jsx";
import { Icon } from "../components/Icons.jsx";
import { useNotes } from "../context/NotesContext.jsx";
import { uid } from "../lib/storage.js";
import { OCR_AVAILABLE, readImages } from "../lib/ocr.js";

const ACCEPT = ["image/jpeg", "image/png", "image/webp"];
const MAX_BYTES = 10 * 1024 * 1024;
const MAX_FILES = 12;
const STEPS = ["Upload", "Review text", "Style & save"];

const STYLES = [
  { id: "clean", label: "Clean transcription", help: "Your reviewed text, kept word for word.", ready: true },
  { id: "exam", label: "Exam revision layout", help: "Empty sections (definitions, formulas, dates, examples) with your text underneath, for you to organise.", ready: true },
  { id: "points", label: "Important points", help: "Concise bullets picked from your text.", ready: false },
  { id: "qa", label: "Question-and-answer sheet", help: "Revision questions made from your text.", ready: false },
  { id: "cards", label: "Flashcards", help: "Cards generated from your text.", ready: false },
  { id: "flow", label: "Flowchart from the text", help: "A process drawn automatically from your notes.", ready: false },
];

const fmtSize = (b) => (b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.round(b / 1024)} KB`);

function loadImg(url) {
  return new Promise((res, rej) => {
    const i = new Image();
    i.onload = () => res(i);
    i.onerror = () => rej(new Error("decode"));
    i.src = url;
  });
}

/** Real, local checks: size in pixels and average brightness. Blur is not detected. */
async function analyze(url) {
  const el = await loadImg(url);
  const w = el.naturalWidth;
  const h = el.naturalHeight;
  const c = document.createElement("canvas");
  c.width = 48;
  c.height = 48;
  const ctx = c.getContext("2d");
  ctx.drawImage(el, 0, 0, 48, 48);
  const d = ctx.getImageData(0, 0, 48, 48).data;
  let sum = 0;
  for (let i = 0; i < d.length; i += 4) sum += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
  const avg = sum / (48 * 48);
  const warnings = [];
  if (Math.min(w, h) < 700) warnings.push("Low resolution. Small writing may be hard to read; retake closer if you can.");
  if (avg < 60) warnings.push("Looks dark. Retake in better light.");
  return { w, h, warnings };
}

async function rotate90(img) {
  const el = await loadImg(img.url);
  const c = document.createElement("canvas");
  c.width = el.naturalHeight;
  c.height = el.naturalWidth;
  const ctx = c.getContext("2d");
  ctx.translate(c.width / 2, c.height / 2);
  ctx.rotate(Math.PI / 2);
  ctx.drawImage(el, -el.naturalWidth / 2, -el.naturalHeight / 2);
  const blob = await new Promise((r) => c.toBlob(r, "image/jpeg", 0.92));
  URL.revokeObjectURL(img.url);
  return { ...img, url: URL.createObjectURL(blob), file: new File([blob], img.name, { type: "image/jpeg" }), w: c.width, h: c.height, size: blob.size };
}

export default function ImageNotesWizard() {
  const nav = useNavigate();
  const { add } = useNotes();
  const [step, setStep] = useState(0);
  const [images, setImages] = useState([]);
  const [errors, setErrors] = useState([]);
  const [busy, setBusy] = useState(false);
  const [sel, setSel] = useState(0);
  const [text, setText] = useState("");
  const [style, setStyle] = useState("clean");
  const [withFlow, setWithFlow] = useState(false);
  const [meta, setMeta] = useState({ title: "", subject: "", grade: "", chapter: "" });
  const [drag, setDrag] = useState(false);
  const [reading, setReading] = useState(false);
  const [progress, setProgress] = useState({ fraction: 0, status: "" });
  const [ocrPages, setOcrPages] = useState([]);
  const [ocrMsg, setOcrMsg] = useState("");
  const [pending, setPending] = useState(null);
  const sig = useRef({ cancelled: false });
  const fileRef = useRef(null);
  const areaRef = useRef(null);
  const live = useRef(images);
  live.current = images;

  useEffect(() => () => { sig.current.cancelled = true; live.current.forEach((i) => URL.revokeObjectURL(i.url)); }, []);

  const runOcr = async () => {
    setOcrMsg("");
    setOcrPages([]);
    setReading(true);
    setProgress({ fraction: 0, status: "Starting…" });
    const signal = { cancelled: false };
    sig.current = signal;
    try {
      const r = await readImages(images, { onProgress: setProgress, signal });
      if (r.cancelled) {
        setOcrMsg("Reading cancelled. Nothing was changed.");
      } else {
        setOcrPages(r.pages);
        if (text.trim()) setPending(r.text);
        else setText(r.text);
      }
    } catch {
      setOcrMsg("The reading engine couldn't start in this browser. You can still type or paste the text yourself.");
    } finally {
      setReading(false);
    }
  };
  const cancelOcr = () => { sig.current.cancelled = true; setProgress((p) => ({ ...p, status: "Stopping…" })); };

  const addFiles = async (list) => {
    const errs = [];
    const next = [];
    const room = MAX_FILES - images.length;
    for (const f of Array.from(list)) {
      if (!ACCEPT.includes(f.type)) errs.push(`${f.name}: not supported. Use a JPG, PNG or WEBP photo.`);
      else if (f.size > MAX_BYTES) errs.push(`${f.name}: ${fmtSize(f.size)} is over the 10 MB limit. Retake or compress it.`);
      else if (next.length >= room) errs.push(`${f.name}: not added. You can use up to ${MAX_FILES} images at a time.`);
      else next.push({ id: uid(), file: f, url: URL.createObjectURL(f), name: f.name, size: f.size, w: 0, h: 0, warnings: [] });
    }
    setBusy(true);
    const ok = [];
    for (const img of next) {
      try {
        const a = await analyze(img.url);
        ok.push({ ...img, ...a });
      } catch {
        URL.revokeObjectURL(img.url);
        errs.push(`${img.name}: this file couldn't be opened as an image. It may be corrupted.`);
      }
    }
    setImages((p) => [...p, ...ok]);
    setErrors(errs);
    setBusy(false);
  };

  const remove = (id) => {
    setImages((p) => {
      const t = p.find((i) => i.id === id);
      if (t) URL.revokeObjectURL(t.url);
      return p.filter((i) => i.id !== id);
    });
    setSel(0);
  };
  const move = (idx, d) => setImages((p) => { const n = [...p]; const j = idx + d; if (j < 0 || j >= n.length) return p; [n[idx], n[j]] = [n[j], n[idx]]; return n; });
  const doRotate = async (id) => {
    const t = images.find((i) => i.id === id);
    if (!t) return;
    const r = await rotate90(t);
    const a = await analyze(r.url);
    setImages((p) => p.map((i) => (i.id === id ? { ...r, ...a } : i)));
  };

  const insertFlag = () => {
    const el = areaRef.current;
    const pos = el ? el.selectionStart : text.length;
    const flag = "[check this: ]";
    setText((t) => t.slice(0, pos) + flag + t.slice(pos));
    window.setTimeout(() => { if (el) { el.focus(); el.setSelectionRange(pos + 13, pos + 13); } }, 0);
  };

  const build = () => {
    let body = text.trim();
    if (style === "exam") {
      body = `## Key terms\n\n\n## Definitions\n\n\n## Formulas\n\n\n## Dates & facts\n\n\n## Examples\n\n\n## Source text (from your images)\n\n${body}`;
    }
    const id = add({
      title: meta.title.trim() || "Notes from images",
      subject: meta.subject, grade: meta.grade, chapter: meta.chapter,
      body, flow: withFlow ? FLOW_STARTER : "", source: "images",
    });
    nav(`/notes/${id}`);
  };

  const cur = images[sel] || images[0];
  const unreadable = images.filter((i) => i.warnings.length);

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <Link to="/notes" className="back">← Notes Studio</Link>
          <h1>Make notes from images</h1>
        </div>
      </div>

      <ol className="steps" aria-label="Progress">
        {STEPS.map((s, i) => (
          <li key={s} className={i === step ? "is-now" : i < step ? "is-past" : ""} aria-current={i === step ? "step" : undefined}>
            <span>{i + 1}</span> {s}
          </li>
        ))}
      </ol>

      <p className="note privacy">
        <Icon name="shield" size={16} /> <span><strong>Privacy:</strong> your images stay in this browser. Reading the text runs on this device with a built-in engine, so nothing is uploaded or sent to any service. Only the text you save is kept, not the pictures.</span>
      </p>

      {step === 0 && (
        <section className="card" aria-labelledby="up">
          <h2 id="up">1. Add photos of your pages</h2>
          <div
            className={`drop ${drag ? "is-drag" : ""}`}
            onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => { e.preventDefault(); setDrag(false); addFiles(e.dataTransfer.files); }}
          >
            <Icon name="image" size={32} />
            <p><strong>Drag photos here</strong> or choose them below</p>
            <p className="muted small">JPG, PNG or WEBP · up to 10 MB each · up to {MAX_FILES} images. Flat, well-lit, in focus works best. Printed pages read best.</p>
            <div className="row-actions wrap center">
              <button type="button" className="btn btn-primary" onClick={() => fileRef.current?.click()} disabled={busy || images.length >= MAX_FILES}>Choose photos</button>
              <label className="btn btn-ghost cam">
                Take a photo
                <input type="file" accept="image/*" capture="environment" className="sr-only" onChange={(e) => { addFiles(e.target.files); e.target.value = ""; }} />
              </label>
            </div>
            <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" multiple className="sr-only" aria-label="Choose image files" onChange={(e) => { addFiles(e.target.files); e.target.value = ""; }} />
          </div>

          {busy && <p className="muted" role="status">Checking images…</p>}
          {errors.length > 0 && (
            <ul className="banner banner-warn err-list" role="alert">
              {errors.map((e) => <li key={e}>{e}</li>)}
            </ul>
          )}

          {images.length > 0 && (
            <>
              <h3 className="small-h">{images.length} image{images.length === 1 ? "" : "s"} · in reading order</h3>
              <ol className="thumbs">
                {images.map((im, i) => (
                  <li key={im.id} className="thumb">
                    <img src={im.url} alt={`Page ${i + 1}: ${im.name}`} />
                    <div className="thumb-info">
                      <strong>{i + 1}. {im.name}</strong>
                      <span className="muted small">{im.w}×{im.h} · {fmtSize(im.size)}</span>
                      {im.warnings.map((w) => <span key={w} className="warn-line">⚠ {w}</span>)}
                    </div>
                    <div className="thumb-actions">
                      <button type="button" className="icon-btn icon-btn-sm" aria-label={`Move ${im.name} earlier`} onClick={() => move(i, -1)} disabled={i === 0}>↑</button>
                      <button type="button" className="icon-btn icon-btn-sm" aria-label={`Move ${im.name} later`} onClick={() => move(i, 1)} disabled={i === images.length - 1}>↓</button>
                      <button type="button" className="icon-btn icon-btn-sm" aria-label={`Rotate ${im.name} 90 degrees`} onClick={() => doRotate(im.id)}><Icon name="reset" size={16} /></button>
                      <button type="button" className="icon-btn icon-btn-sm" aria-label={`Remove ${im.name}`} onClick={() => remove(im.id)}><Icon name="trash" size={16} /></button>
                    </div>
                  </li>
                ))}
              </ol>
              {unreadable.length > 0 && <p className="muted small">Brightness and size are checked here. Blurry photos can't be detected automatically, so check each one.</p>}
            </>
          )}

          <div className="row-actions end">
            <button type="button" className="btn btn-primary" disabled={images.length === 0 || busy} onClick={() => { setSel(0); setStep(1); }}>
              Continue <Icon name="arrow" size={16} />
            </button>
          </div>
        </section>
      )}

      {step === 1 && cur && (
        <section className="card" aria-labelledby="rv">
          <h2 id="rv">2. Review the text next to your original</h2>
          <div className="review">
            <div className="review-img">
              <div className="strip" role="group" aria-label="Choose page">
                {images.map((im, i) => (
                  <button key={im.id} type="button" className={`strip-btn ${i === sel ? "on" : ""}`} aria-pressed={i === sel} aria-label={`Show page ${i + 1}`} onClick={() => setSel(i)}>
                    <img src={im.url} alt="" />
                  </button>
                ))}
              </div>
              <div className="viewer">
                <img src={cur.url} alt={`Original page ${sel + 1}: ${cur.name}`} />
              </div>
              <a href={cur.url} target="_blank" rel="noopener noreferrer" className="small">Open this page full size</a>
            </div>

            <div className="review-text">
              <div className="note ocr-panel">
                <strong>Read text from my photos <span className="status-pill status-live">On this device</span></strong>
                <p className="small">Works well on clear <strong>printed</strong> pages (textbooks, typed notes). It cannot read handwriting reliably, and equations and diagrams need checking. Doubtful words are marked “[check this: …]” for you to verify against your original.</p>
                {!OCR_AVAILABLE ? (
                  <>
                    <p className="banner banner-warn small" role="status">You opened StudyAura as a local file, and browsers block the reading engine in that case. Start it from a web address (see “Run it” in the README: one command), or type the text from your page yourself.</p>
                    <button type="button" className="btn btn-ghost btn-sm" disabled>Read text from photos (needs a web address)</button>
                  </>
                ) : !reading ? (
                  <button type="button" className="btn btn-primary btn-sm" onClick={runOcr}>Read text from {images.length} page{images.length === 1 ? "" : "s"}</button>
                ) : (
                  <div className="ocr-run">
                    <div className="progress" role="progressbar" aria-label="Reading progress" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(progress.fraction * 100)}><span style={{ width: `${Math.round(progress.fraction * 100)}%` }} /></div>
                    <p className="small" role="status">{progress.status}</p>
                    <button type="button" className="btn btn-ghost btn-sm" onClick={cancelOcr}>Cancel</button>
                  </div>
                )}
                {ocrMsg && <p className="small" role="status">{ocrMsg}</p>}
                {ocrPages.length > 0 && (
                  <ul className="ocr-results" aria-label="Reading results per page">
                    {ocrPages.map((pg) => (
                      <li key={pg.index} className={`q-${pg.quality}`}>
                        <strong>Page {pg.index + 1}</strong>
                        {pg.quality === "none" ? <span>No text found. Is the page blank, too dark, or only a picture?</span> : (
                          <span>
                            {{ good: "Clear read", fair: "Fair read", poor: "Poor read" }[pg.quality]} ({pg.confidence}% sure) · {pg.flags} spot{pg.flags === 1 ? "" : "s"} to check{pg.rotated ? " · page was sideways, turned automatically" : ""}
                            {pg.quality === "poor" && " · This looks like handwriting or an unclear photo. Please type this page yourself, using the original beside it."}
                          </span>
                        )}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <label className="field">
                <span>Text from your images (read automatically, or type, paste and correct)</span>
                <textarea ref={areaRef} className="area area-tall" value={text} onChange={(e) => setText(e.target.value)} placeholder="Type or paste the words from the page. For anything you can't read, use the flag button." />
              </label>
              <div className="row-actions wrap">
                <button type="button" className="btn btn-soft btn-sm" onClick={insertFlag}>Insert “check this” flag</button>
                <span className="muted small">{text.trim() ? text.trim().split(/\s+/).length : 0} words</span>
              </div>
              <p className="muted small">For maths, copy symbols, exponents and fractions exactly as printed. If you're unsure, flag it instead of guessing. Diagrams can't be typed, so mention them in the text and keep your photos.</p>
            </div>
          </div>
          <div className="row-actions end">
            <button type="button" className="btn btn-ghost" onClick={() => setStep(0)}>Back</button>
            <button type="button" className="btn btn-primary" disabled={!text.trim()} onClick={() => setStep(2)}>Continue <Icon name="arrow" size={16} /></button>
          </div>
          {!text.trim() && <p className="muted small right">Add some text to continue.</p>}
        </section>
      )}

      {step === 2 && (
        <section className="card" aria-labelledby="st">
          <h2 id="st">3. Choose a style and save</h2>
          <fieldset className="styles">
            <legend className="sr-only">Output style</legend>
            {STYLES.map((s) => (
              <label key={s.id} className={`style ${s.ready ? "" : "is-off"} ${style === s.id ? "is-on" : ""}`}>
                <input type="radio" name="style" value={s.id} checked={style === s.id} disabled={!s.ready} onChange={() => setStyle(s.id)} />
                <span>
                  <strong>{s.label}</strong> {!s.ready && <em className="status-pill status-off">Needs AI connection</em>}
                  <span className="muted small block">{s.help}</span>
                </span>
              </label>
            ))}
          </fieldset>
          <label className="check-line">
            <input type="checkbox" checked={withFlow} onChange={(e) => setWithFlow(e.target.checked)} />
            <span>Add a flowchart starter to draw by hand (automatic flowcharts need the AI connection)</span>
          </label>

          <div className="form-grid">
            <label className="field wide"><span>Title</span><input value={meta.title} onChange={(e) => setMeta({ ...meta, title: e.target.value })} placeholder="e.g. Chapter 4 revision" maxLength={120} /></label>
            <label className="field"><span>Subject</span><input value={meta.subject} onChange={(e) => setMeta({ ...meta, subject: e.target.value })} maxLength={40} /></label>
            <label className="field"><span>Class / grade</span><input value={meta.grade} onChange={(e) => setMeta({ ...meta, grade: e.target.value })} maxLength={20} /></label>
            <label className="field wide"><span>Chapter / topic</span><input value={meta.chapter} onChange={(e) => setMeta({ ...meta, chapter: e.target.value })} maxLength={80} /></label>
          </div>

          <div className="row-actions end">
            <button type="button" className="btn btn-ghost" onClick={() => setStep(1)}>Back</button>
            <button type="button" className="btn btn-primary" onClick={build}>Create note</button>
          </div>
        </section>
      )}
      <ConfirmDialog
        open={pending !== null}
        title="Replace your current text?"
        message="The text box already has content. Replace it with what was just read from your photos? Your current text will be lost."
        confirmLabel="Replace"
        onConfirm={() => { setText(pending); setPending(null); }}
        onCancel={() => { setPending(null); setOcrMsg("Kept your current text. The new reading was discarded."); }}
      />
    </div>
  );
}
