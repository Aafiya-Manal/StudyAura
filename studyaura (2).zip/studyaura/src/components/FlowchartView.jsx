import { useEffect, useState } from "react";

let counter = 0;

/** Renders Mermaid flowchart text to SVG (client-side, lazy-loaded). Invalid text shows a clear error, never a blank box. */
export default function FlowchartView({ code }) {
  const [svg, setSvg] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let dead = false;
    if (!code.trim()) {
      setSvg("");
      setError("");
      setLoading(false);
      return undefined;
    }
    setLoading(true);
    const t = window.setTimeout(async () => {
      const id = `flow-${++counter}`;
      try {
        const mermaid = (await import("mermaid")).default;
        mermaid.initialize({
          startOnLoad: false,
          securityLevel: "strict",
          theme: "base",
          themeVariables: { primaryColor: "#ece8ff", primaryBorderColor: "#6c4bff", primaryTextColor: "#16143a", lineColor: "#6c4bff", fontFamily: "Space Grotesk, sans-serif" },
        });
        const out = await mermaid.render(id, code);
        if (!dead) {
          setSvg(out.svg);
          setError("");
        }
      } catch {
        document.getElementById(`d${id}`)?.remove();
        if (!dead) {
          setSvg("");
          setError("This flowchart text has a mistake, so it can't be drawn yet. Check each line looks like: A[Step one] --> B[Step two]");
        }
      } finally {
        if (!dead) setLoading(false);
      }
    }, 400);
    return () => {
      dead = true;
      window.clearTimeout(t);
    };
  }, [code]);

  if (!code.trim()) return <div className="empty"><p><strong>No flowchart yet.</strong></p><p>Write steps on the left, or use the starter, and the drawing appears here.</p></div>;
  return (
    <div className="flow-view" aria-live="polite">
      {loading && !svg && <p className="muted">Drawing…</p>}
      {error && <p className="banner banner-warn" role="alert">{error}</p>}
      {svg && <div className="flow-svg" role="img" aria-label="Flowchart preview" dangerouslySetInnerHTML={{ __html: svg }} />}
    </div>
  );
}

export const FLOW_STARTER = `flowchart TD
  A[Start: the idea] --> B{Decision or question?}
  B -- Yes --> C[Step if yes]
  B -- No --> D[Step if no]
  C --> E[Result]
  D --> E`;
