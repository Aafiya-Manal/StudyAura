import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import ConfirmDialog from "../components/ConfirmDialog.jsx";
import { Icon } from "../components/Icons.jsx";
import { countFlags, useNotes } from "../context/NotesContext.jsx";

export default function NotesPage() {
  const { notes, add, duplicate, remove } = useNotes();
  const nav = useNavigate();
  const [q, setQ] = useState("");
  const [del, setDel] = useState(null);

  const shown = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return notes;
    return notes.filter((n) => [n.title, n.subject, n.chapter, n.grade, n.body].join(" ").toLowerCase().includes(s));
  }, [notes, q]);

  return (
    <div className="page">
      <div className="page-head">
        <h1>Notes Studio</h1>
        <div className="row-actions">
          <button type="button" className="btn btn-ghost" onClick={() => nav(`/notes/${add({ title: "Untitled note" })}`)}>
            <Icon name="plus" size={16} /> Blank note
          </button>
          <Link to="/notes/from-images" className="btn btn-primary"><Icon name="image" size={16} /> Make notes from images</Link>
        </div>
      </div>

      <label className="search">
        <span className="sr-only">Search notes</span>
        <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by title, subject, chapter or text" />
      </label>

      {notes.length === 0 ? (
        <section className="card empty-big">
          <h2>No notes yet</h2>
          <p className="muted">Start from photos of a textbook page or handwritten notes, or write a blank note. Notes are saved on this device only.</p>
          <Link to="/notes/from-images" className="btn btn-primary"><Icon name="image" size={16} /> Make notes from images</Link>
        </section>
      ) : shown.length === 0 ? (
        <div className="empty"><p><strong>No notes match “{q}”.</strong></p></div>
      ) : (
        <ul className="note-grid">
          {shown.map((n) => {
            const flags = countFlags(n.body);
            return (
              <li key={n.id} className="card note-card">
                <Link to={`/notes/${n.id}`} className="note-link">
                  <strong>{n.title}</strong>
                  <span className="muted small">{[n.subject, n.grade && `Class ${n.grade}`, n.chapter].filter(Boolean).join(" · ") || "No subject set"}</span>
                  <span className="note-snippet">{n.body.trim().slice(0, 130) || "Empty note"}</span>
                </Link>
                <div className="note-foot">
                  <span className="small muted">{new Date(n.updatedAt).toLocaleDateString()}</span>
                  {flags > 0 && <span className="status-pill status-soon">{flags} to check</span>}
                  {n.flow?.trim() && <span className="status-pill status-live">Flowchart</span>}
                  <span className="spacer" />
                  <button type="button" className="icon-btn icon-btn-sm" aria-label={`Duplicate ${n.title}`} onClick={() => duplicate(n.id)}><Icon name="cards" size={16} /></button>
                  <button type="button" className="icon-btn icon-btn-sm" aria-label={`Delete ${n.title}`} onClick={() => setDel(n)}><Icon name="trash" size={16} /></button>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <ConfirmDialog
        open={!!del}
        title="Delete this note?"
        message={del ? `“${del.title}” will be removed from this device. This can't be undone.` : ""}
        onConfirm={() => { remove(del.id); setDel(null); }}
        onCancel={() => setDel(null)}
      />
    </div>
  );
}
