import { AppIcon, BRAND, LogoMark, Wordmark } from "../brand/Logo.jsx";

const SWATCHES = [
  ["Violet", BRAND.violet], ["Soft violet", BRAND.violetLight], ["Electric blue", BRAND.blue], ["Mint", "#6EE7C5"], ["Cream", "#FFE9C2"], ["Night navy", BRAND.navy],
];

export default function BrandPage() {
  return (
    <div className="page">
      <h1>Brand sheet</h1>

      <section className="card brand-hero" aria-labelledby="b1">
        <h2 id="b1" className="sr-only">Full wordmark</h2>
        <Wordmark size={84} tagline />
      </section>

      <div className="brand-grid">
        <section className="card" aria-labelledby="b2">
          <h2 id="b2">Small-size test</h2>
          <p className="muted small">The mark at 24, 32, 48 px on light and dark.</p>
          <div className="swatch-row bg-light">
            {[24, 32, 48].map((s) => <LogoMark key={s} size={s} />)}
            {[24, 32, 48].map((s) => <span key={`m${s}`} className="mono-ink"><LogoMark size={s} variant="mono" /></span>)}
          </div>
          <div className="swatch-row bg-dark">
            {[24, 32, 48].map((s) => <LogoMark key={s} size={s} />)}
            {[24, 32, 48].map((s) => <span key={`m${s}`} className="mono-paper"><LogoMark size={s} variant="mono" /></span>)}
          </div>
        </section>

        <section className="card" aria-labelledby="b3">
          <h2 id="b3">App icon</h2>
          <div className="swatch-row">
            <AppIcon size={96} />
            <AppIcon size={96} tone="light" />
            <AppIcon size={48} />
            <AppIcon size={32} />
            <AppIcon size={24} />
          </div>
        </section>

        <section className="card" aria-labelledby="b4">
          <h2 id="b4">Wordmark: light, dark, monochrome</h2>
          <div className="stack">
            <div className="bg-light pad"><Wordmark size={40} /></div>
            <div className="bg-dark pad"><Wordmark size={40} /></div>
            <div className="bg-light pad mono-ink"><Wordmark size={40} variant="mono" /></div>
            <div className="bg-dark pad mono-paper"><Wordmark size={40} variant="mono" /></div>
          </div>
        </section>

        <section className="card" aria-labelledby="b5">
          <h2 id="b5">Colour &amp; type</h2>
          <ul className="swatches">
            {SWATCHES.map(([n, c]) => (
              <li key={n}><span style={{ background: c }} aria-hidden="true" /> {n} <code>{c}</code></li>
            ))}
          </ul>
          <p className="muted">Typeface: Space Grotesk (self-hosted, 400–700).</p>
        </section>
      </div>
    </div>
  );
}
