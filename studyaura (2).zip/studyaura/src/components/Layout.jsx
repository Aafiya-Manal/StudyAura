import { useEffect, useRef, useState } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import { LogoMark, Wordmark } from "../brand/Logo.jsx";
import { Icon } from "./Icons.jsx";
import AuraPet from "./AuraPet.jsx";
import { storageStatus } from "../lib/storage.js";

/** status: "live" = works today · "soon" = not built yet · "off" = needs setup / not connected */
export const NAV = [
  { to: "/", label: "Home", icon: "home", status: "live", end: true },
  { to: "/library", label: "My Courses", icon: "book", status: "soon" },
  { to: "/assistant", label: "AI Assistant", icon: "sparkle", status: "off" },
  { to: "/flashcards", label: "Flashcards", icon: "cards", status: "soon" },
  { to: "/practice", label: "Practice & Tests", icon: "target", status: "soon" },
  { to: "/planner", label: "Study Planner", icon: "calendar", status: "soon" },
  { to: "/focus", label: "Focus", icon: "timer", status: "live" },
  { to: "/notes", label: "Notes", icon: "note", status: "beta" },
  { to: "/mood", label: "Mood Tracker", icon: "smile", status: "soon" },
  { to: "/settings", label: "Settings", icon: "gear", status: "live" },
];

const TAG = { soon: "Soon", off: "Setup", beta: "Beta" };

export default function Layout() {
  const [open, setOpen] = useState(false);
  const loc = useLocation();
  const menuBtn = useRef(null);

  useEffect(() => setOpen(false), [loc.pathname]);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => {
      if (e.key === "Escape") {
        setOpen(false);
        menuBtn.current?.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <div className="app">
      <a className="skip" href="#main" onClick={(e) => { e.preventDefault(); document.getElementById("main")?.focus(); }}>Skip to content</a>

      <aside id="sidebar" className={`sidebar ${open ? "is-open" : ""}`} aria-label="Primary">
        <div className="sidebar-top">
          <NavLink to="/" className="brand-link" aria-label="StudyAura home">
            <Wordmark size={34} />
          </NavLink>
          <button type="button" className="icon-btn sidebar-close" onClick={() => setOpen(false)} aria-label="Close menu">
            <Icon name="close" />
          </button>
        </div>

        <nav className="nav" aria-label="Main navigation">
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} className={({ isActive }) => `nav-item ${isActive ? "is-active" : ""}`}>
              <Icon name={n.icon} />
              <span className="nav-label">{n.label}</span>
              {TAG[n.status] && <span className="nav-tag">{TAG[n.status]}</span>}
            </NavLink>
          ))}
        </nav>

        <div className="night-card" aria-hidden="true">
          <p>Small steps daily create big results.</p>
          <span className="night-moon" />
        </div>
      </aside>
      {open && <button type="button" className="scrim" aria-label="Close menu" onClick={() => setOpen(false)} />}

      <div className="stage">
        <header className="topbar">
          <button ref={menuBtn} type="button" className="icon-btn" onClick={() => setOpen(true)} aria-label="Open menu" aria-expanded={open} aria-controls="sidebar">
            <Icon name="menu" />
          </button>
          <NavLink to="/" className="brand-link" aria-label="StudyAura home">
            <Wordmark size={28} />
          </NavLink>
          <span className="topbar-spacer" />
        </header>

        <main id="main" className="main" tabIndex={-1}>
          {!storageStatus.ok && (
            <p className="banner banner-warn" role="alert">
              Your browser is blocking local storage, so changes won't be saved after you close this tab.
            </p>
          )}
          <Outlet />
          <footer className="footer">
            <LogoMark size={20} decorative />
            <span>Made by a student. Built for students.</span>
          </footer>
        </main>
      </div>

      <nav className="tabbar" aria-label="Quick navigation">
        <NavLink to="/" end className="tab"><Icon name="home" /><span>Home</span></NavLink>
        <NavLink to="/planner" className="tab"><Icon name="calendar" /><span>Plan</span></NavLink>
        <NavLink to="/focus" className="tab"><Icon name="timer" /><span>Focus</span></NavLink>
        <NavLink to="/notes" className="tab"><Icon name="note" /><span>Notes</span></NavLink>
        <button type="button" className="tab" onClick={() => setOpen(true)} aria-expanded={open} aria-controls="sidebar">
          <Icon name="menu" /><span>More</span>
        </button>
      </nav>

      <AuraPet />
    </div>
  );
}
