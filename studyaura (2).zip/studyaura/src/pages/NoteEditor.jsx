import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import ConfirmDialog from "../components/ConfirmDialog.jsx";
import FlowchartView, { FLOW_STARTER } from "../components/FlowchartView.jsx";
import { Icon } from "../components/Icons.jsx";
import { countFlags, download, safeName, toMarkdown, toText, useNotes } from "../context/NotesContext.jsx";

export default function NoteEditor() {
  const { id } = useParams();
  const nav = useNavigate();
  const { notes, update, duplicate, remove } = useNotes();
  const note = notes.find((n) => n.id === id);

  const [draft, setDraft] = useState(note);
  const [saved, setSaved] = useState(true);
  const [msg, setMsg] = useState("");
  const [del, setDel] = useState(false);

  useEffect(() => {
    setDraft(note);
    setSaved(true);
  }, [id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!note || !draft) {
    return (
      <div className="page page-narrow">
        <section className="card"><h1>Note not found</h1><p className="muted">It may have been deleted.</p><Link to="/notes" className="btn btn-soft">Back to notes</Link></section>
      </div>
    );
  }

  const set = (k) => (e) => { setDraft((d) => ({ ...d, [k]: e.target.value })); setSaved(false); setMsg(""); };
  const save = () => { update(id, { title: draft.title.trim() || "Untitled note", subject: draft.subject, grade: draft.grade, chapter: draft.chapter, body: draft.body, flow: draft.flow }); setSaved(true); setMsg("Saved on this device."); };
  const cur = { ...draft, title: draft.title.trim() || "Untitled note" };
  const flags = countFlags(draft.body);

  const copy = async () => {
    try { await navigator.clipboard.writeText(toMarkdown(cur)); setMsg("Copied to clipboard."); } catch { setMsg("Couldn't copy automatically. Select the text and copy it yourself."); }
  };

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <Link to="/notes" className="back">← All notes</Link>
          <h1>Edit note</h1>
        </div>
        <div className="row-actions">
          <button type="button" className="btn btn-primary" onClick={save} disabled={saved}>{saved ? "Saved" : "Save changes"}</button>
        </div>
      </div>

      {flags > 0 && <p className="banner banner-warn" role="status">{flags} item{flags === 1 ? "" : "s"} marked “[check this]”. Compare with your original and fix them before relying on this note.</p>}
      {!saved && <p className="muted small" role="status">You have unsaved changes.</p>}
      {msg && <p className="muted small" role="status">{msg}</p>}

      <section className="card form-card" aria-label="Note details">
        <label className="field wide"><span>Title</span><input value={draft.title} onChange={set("title")} maxLength={120} /></label>
        <label className="field"><span>Subject</span><input value={draft.subject} onChange={set("subject")} maxLength={40} placeholder="e.g. Physics" /></label>
        <label className="field"><span>Class / grade</span><input value={draft.grade} onChange={set("grade")} maxLength={20} placeholder="e.g. 10" /></label>
        <label className="field wide"><span>Chapter / topic</span><input value={draft.chapter} onChange={set("chapter")} maxLength={80} /></label>
      </section>

      <div className="split">
        <section className="card">
          <label className="field"><span>Notes</span>
            <textarea className="area area-tall" value={draft.body} onChange={set("body")} spellCheck />
          </label>
        </section>

        <section className="card">
          <div className="card-head"><h2>Flowchart</h2>
            {!draft.flow.trim() && <button type="button" className="btn btn-soft btn-sm" onClick={() => { setDraft((d) => ({ ...d, flow: FLOW_STARTER })); setSaved(false); }}>Use starter</button>}
          </div>
          <label className="field"><span>Flowchart text (Mermaid)</span>
            <textarea className="area mono" rows={7} value={draft.flow} onChange={set("flow")} spellCheck={false} placeholder="A[Step] --> B[Next step]" />
          </label>
          <p className="muted small">You write the steps yourself for now. Automatic flowcharts from your photos need the AI connection (see Make notes from images).</p>
          <FlowchartView code={draft.flow} />
        </section>
      </div>

      <section className="card">
        <h2>Export &amp; manage</h2>
        <div className="row-actions wrap">
          <button type="button" className="btn btn-ghost" onClick={copy}>Copy as Markdown</button>
          <button type="button" className="btn btn-ghost" onClick={() => download(`${safeName(cur.title)}.md`, toMarkdown(cur), "text/markdown")}><Icon name="note" size={16} /> Download .md</button>
          <button type="button" className="btn btn-ghost" onClick={() => download(`${safeName(cur.title)}.txt`, toText(cur))}>Download .txt</button>
          <button type="button" className="btn btn-ghost" onClick={() => nav(`/notes/${duplicate(id)}`)}>Duplicate</button>
          <button type="button" className="btn btn-danger-soft" onClick={() => setDel(true)}><Icon name="trash" size={16} /> Delete</button>
        </div>
        <p className="muted small">Exports include your latest edits, saved or not. PDF export isn't built yet. Flashcards and quiz from notes are coming in Phase 5.</p>
      </section>

      <ConfirmDialog open={del} title="Delete this note?" message={`“${cur.title}” will be removed from this device. This can't be undone.`} onConfirm={() => { remove(id); nav("/notes"); }} onCancel={() => setDel(false)} />
    </div>
  );
}
