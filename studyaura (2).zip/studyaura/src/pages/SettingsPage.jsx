import { useState } from "react";
import { Link } from "react-router-dom";
import ConfirmDialog from "../components/ConfirmDialog.jsx";
import { Icon } from "../components/Icons.jsx";
import { useData } from "../context/DataContext.jsx";

export default function SettingsPage() {
  const { settings, setPet, resetAll } = useData();
  const [confirm, setConfirm] = useState(false);
  const [done, setDone] = useState(false);

  return (
    <div className="page page-narrow">
      <h1>Settings</h1>

      <section className="card" aria-labelledby="s-pet">
        <h2 id="s-pet">AuraPet</h2>
        <label className="switch">
          <input type="checkbox" role="switch" checked={settings.pet} onChange={(e) => setPet(e.target.checked)} />
          <span className="switch-track" aria-hidden="true" />
          <span>Show the floating helper (it hides itself while a focus session is running)</span>
        </label>
      </section>

      <section className="card" aria-labelledby="s-data">
        <h2 id="s-data">Your data</h2>
        <p className="note">
          <Icon name="shield" size={16} /> Everything is saved in this browser on this device only. It does not sync to other devices, and clearing your browser data will remove it. Nothing is uploaded anywhere.
        </p>
        <button type="button" className="btn btn-danger-soft" onClick={() => { setDone(false); setConfirm(true); }}>Clear all StudyAura data on this device</button>
        {done && <p role="status" className="muted">All local data cleared.</p>}
      </section>

      <section className="card" aria-labelledby="s-brand">
        <h2 id="s-brand">Brand</h2>
        <p className="muted">Logo variants and size tests.</p>
        <Link to="/brand" className="btn btn-soft">Open brand sheet</Link>
      </section>

      <ConfirmDialog
        open={confirm}
        title="Clear all data?"
        message="Your subjects, tasks, mood check-ins and focus history on this device will be permanently deleted."
        confirmLabel="Clear everything"
        onConfirm={() => { resetAll(); setConfirm(false); setDone(true); }}
        onCancel={() => setConfirm(false)}
      />
    </div>
  );
}
