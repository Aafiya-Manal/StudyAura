import { createContext, useCallback, useContext, useMemo } from "react";
import { clearAllLocalData, todayKey, uid, useLocalStorage } from "../lib/storage.js";

const DataContext = createContext(null);

export const SUBJECT_COLORS = ["violet", "blue", "rose", "mint", "amber", "pink"];
export const PRIORITIES = ["high", "medium", "low"];

export function DataProvider({ children }) {
  const [subjects, setSubjects] = useLocalStorage("subjects", []);
  const [tasks, setTasks] = useLocalStorage("tasks", []);
  const [moods, setMoods] = useLocalStorage("moods", {});
  const [settings, setSettings] = useLocalStorage("settings", { pet: true });

  const addSubject = useCallback(
    ({ name, total }) => {
      setSubjects((prev) => [
        ...prev,
        { id: uid(), name: name.trim(), total: Math.max(1, total), done: 0, color: SUBJECT_COLORS[prev.length % SUBJECT_COLORS.length] },
      ]);
    },
    [setSubjects],
  );
  const setSubjectDone = useCallback(
    (id, delta) =>
      setSubjects((prev) => prev.map((s) => (s.id === id ? { ...s, done: Math.min(s.total, Math.max(0, s.done + delta)) } : s))),
    [setSubjects],
  );
  const removeSubject = useCallback((id) => setSubjects((prev) => prev.filter((s) => s.id !== id)), [setSubjects]);

  const addTask = useCallback(
    ({ title, subject, priority, minutes, date }) => {
      setTasks((prev) => [
        ...prev,
        { id: uid(), title: title.trim(), subject: subject || "", priority: priority || "medium", minutes: minutes || 0, date: date || todayKey(), done: false },
      ]);
    },
    [setTasks],
  );
  const toggleTask = useCallback((id) => setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t))), [setTasks]);
  const removeTask = useCallback((id) => setTasks((prev) => prev.filter((t) => t.id !== id)), [setTasks]);

  const setMood = useCallback((value) => setMoods((prev) => ({ ...prev, [todayKey()]: value })), [setMoods]);

  const setPet = useCallback((on) => setSettings((p) => ({ ...p, pet: on })), [setSettings]);

  const resetAll = useCallback(() => {
    clearAllLocalData();
    setSubjects([]);
    setTasks([]);
    setMoods({});
    setSettings({ pet: true });
    try {
      window.localStorage.removeItem("studyaura:v2:sessions");
    } catch {
      /* ignore */
    }
  }, [setSubjects, setTasks, setMoods, setSettings]);

  const value = useMemo(
    () => ({
      subjects, addSubject, setSubjectDone, removeSubject,
      tasks, addTask, toggleTask, removeTask,
      moods, setMood, todayMood: moods[todayKey()] ?? null,
      settings, setPet, resetAll,
    }),
    [subjects, tasks, moods, settings, addSubject, setSubjectDone, removeSubject, addTask, toggleTask, removeTask, setMood, setPet, resetAll],
  );
  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

export const useData = () => useContext(DataContext);
